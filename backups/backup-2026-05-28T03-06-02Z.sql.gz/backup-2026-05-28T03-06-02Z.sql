--
-- PostgreSQL database dump
--

\restrict RYf2HbdMRU1iXX4CpdQ6B9G6TuocZR6yS5yf6gtudpq2SjI43yFMtgmxsKj8hwF

-- Dumped from database version 16.14
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: address; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA address;


--
-- Name: addresses; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA addresses;


--
-- Name: ai; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA ai;


--
-- Name: asaas; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA asaas;


--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- Name: candidate; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA candidate;


--
-- Name: commissions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA commissions;


--
-- Name: coordinator; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA coordinator;


--
-- Name: documents; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA documents;


--
-- Name: enrollment; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA enrollment;


--
-- Name: fees; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA fees;


--
-- Name: hub; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA hub;


--
-- Name: infinitepay; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA infinitepay;


--
-- Name: jwt; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA jwt;


--
-- Name: lead; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA lead;


--
-- Name: notify; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA notify;


--
-- Name: otp; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA otp;


--
-- Name: profiles; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA profiles;


--
-- Name: promoter; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA promoter;


--
-- Name: roles; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA roles;


--
-- Name: staff; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA staff;


--
-- Name: student; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA student;


--
-- Name: training; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA training;


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: lead_status; Type: TYPE; Schema: lead; Owner: -
--

CREATE TYPE lead.lead_status AS ENUM (
    'captured',
    'waiting',
    'checkout',
    'completed'
);


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: profiles; Owner: -
--

CREATE FUNCTION profiles.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = now();
            RETURN NEW;
        END;
        $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: address; Owner: -
--

CREATE TABLE address.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: addresses; Type: TABLE; Schema: addresses; Owner: -
--

CREATE TABLE addresses.addresses (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    zipcode character varying(8) NOT NULL,
    street character varying(200) NOT NULL,
    number character varying(20),
    complement character varying(100),
    neighborhood character varying(100),
    city character varying(100) NOT NULL,
    state character varying(2) NOT NULL,
    country character varying(2) DEFAULT 'BR'::character varying NOT NULL,
    lat character varying(30),
    lng character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: entity_address_details; Type: TABLE; Schema: addresses; Owner: -
--

CREATE TABLE addresses.entity_address_details (
    id uuid NOT NULL,
    street character varying(200),
    number character varying(20),
    complement character varying(100),
    neighborhood character varying(100),
    city character varying(100),
    state character varying(2),
    zipcode character varying(8),
    lat character varying(30),
    lng character varying(30),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: entity_addresses; Type: TABLE; Schema: addresses; Owner: -
--

CREATE TABLE addresses.entity_addresses (
    id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    external_id character varying(100) NOT NULL,
    proof_file character varying(255),
    address_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: asaas; Owner: -
--

CREATE TABLE asaas.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: config; Type: TABLE; Schema: asaas; Owner: -
--

CREATE TABLE asaas.config (
    key character varying NOT NULL,
    value text,
    updated_at timestamp with time zone
);


--
-- Name: customer; Type: TABLE; Schema: asaas; Owner: -
--

CREATE TABLE asaas.customer (
    id uuid NOT NULL,
    external_id character varying NOT NULL,
    asaas_id character varying NOT NULL,
    name character varying NOT NULL,
    cpf_cnpj character varying NOT NULL,
    email character varying,
    mobile_phone character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: payment; Type: TABLE; Schema: asaas; Owner: -
--

CREATE TABLE asaas.payment (
    id uuid NOT NULL,
    payment_id character varying,
    kind character varying,
    pixkey_external_id character varying,
    qrcode_payload text,
    customer_external_id character varying,
    pix_qr_image text,
    due_date date,
    amount double precision,
    description text,
    scheduled_for timestamp with time zone,
    status character varying,
    asaas_id character varying,
    last_error text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: pix_key; Type: TABLE; Schema: asaas; Owner: -
--

CREATE TABLE asaas.pix_key (
    id uuid NOT NULL,
    external_id character varying NOT NULL,
    key character varying,
    key_type character varying,
    holder_document character varying,
    holder_name character varying,
    bank_name character varying,
    validated_at timestamp with time zone,
    raw_dict text
);


--
-- Name: url_verify_nonce; Type: TABLE; Schema: asaas; Owner: -
--

CREATE TABLE asaas.url_verify_nonce (
    nonce character varying NOT NULL,
    target_url text NOT NULL,
    purpose character varying NOT NULL,
    created_at timestamp with time zone,
    consumed_at timestamp with time zone
);


--
-- Name: webhook_event; Type: TABLE; Schema: asaas; Owner: -
--

CREATE TABLE asaas.webhook_event (
    id uuid NOT NULL,
    received_at timestamp with time zone,
    event character varying,
    payload text,
    forwarded_ok boolean,
    forwarded_at timestamp with time zone,
    source_ip character varying(64),
    user_agent text
);


--
-- Name: alembic_version; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    family_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: role_rules; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.role_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    from_role character varying,
    to_role character varying NOT NULL,
    mode character varying NOT NULL,
    requires_role character varying,
    forbids_role character varying,
    blocking boolean DEFAULT false NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    external_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: candidate; Owner: -
--

CREATE TABLE candidate.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: candidates; Type: TABLE; Schema: candidate; Owner: -
--

CREATE TABLE candidate.candidates (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    hub_external_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: enrollment; Owner: -
--

CREATE TABLE enrollment.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: educational_data; Type: TABLE; Schema: enrollment; Owner: -
--

CREATE TABLE enrollment.educational_data (
    id uuid NOT NULL,
    enrollment_id uuid NOT NULL,
    last_year_studied integer NOT NULL,
    last_year_date date NOT NULL,
    last_school character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: enrollment_events; Type: TABLE; Schema: enrollment; Owner: -
--

CREATE TABLE enrollment.enrollment_events (
    id bigint NOT NULL,
    external_id uuid NOT NULL,
    event character varying(64) NOT NULL,
    promoter_external_id uuid,
    payload jsonb NOT NULL,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone
);


--
-- Name: enrollment_events_id_seq; Type: SEQUENCE; Schema: enrollment; Owner: -
--

CREATE SEQUENCE enrollment.enrollment_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enrollment_events_id_seq; Type: SEQUENCE OWNED BY; Schema: enrollment; Owner: -
--

ALTER SEQUENCE enrollment.enrollment_events_id_seq OWNED BY enrollment.enrollment_events.id;


--
-- Name: enrollments; Type: TABLE; Schema: enrollment; Owner: -
--

CREATE TABLE enrollment.enrollments (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    status character varying(24) NOT NULL,
    promoter_external_id uuid,
    hub_external_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: fees; Owner: -
--

CREATE TABLE fees.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: fee; Type: TABLE; Schema: fees; Owner: -
--

CREATE TABLE fees.fee (
    id uuid NOT NULL,
    student_external_id uuid NOT NULL,
    coordinator_external_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: fee_payment; Type: TABLE; Schema: fees; Owner: -
--

CREATE TABLE fees.fee_payment (
    id uuid NOT NULL,
    fee_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    payment_id character varying(80) NOT NULL,
    qrcode_payload text NOT NULL,
    amount double precision NOT NULL,
    scheduled_date date,
    status character varying(24) NOT NULL,
    asaas_id character varying(64),
    last_error text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: hub; Owner: -
--

CREATE TABLE hub.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: hub; Type: TABLE; Schema: hub; Owner: -
--

CREATE TABLE hub.hub (
    id uuid NOT NULL,
    name character varying(120) NOT NULL,
    brand character varying(40) NOT NULL,
    address_external_id uuid,
    coordinator_external_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: infinitepay; Owner: -
--

CREATE TABLE infinitepay.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: checkouts; Type: TABLE; Schema: infinitepay; Owner: -
--

CREATE TABLE infinitepay.checkouts (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    checkout_url text NOT NULL,
    is_paid boolean NOT NULL,
    receipt_url text,
    installments integer,
    invoice_slug character varying(128),
    capture_method character varying(32),
    transaction_nsu character varying(128),
    request_payload json NOT NULL,
    response_payload json NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: outbound_jobs; Type: TABLE; Schema: infinitepay; Owner: -
--

CREATE TABLE infinitepay.outbound_jobs (
    id uuid NOT NULL,
    url text NOT NULL,
    payload json NOT NULL,
    external_id uuid,
    attempts integer NOT NULL,
    max_attempts integer NOT NULL,
    next_attempt_at timestamp with time zone NOT NULL,
    delivered_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhook_logs; Type: TABLE; Schema: infinitepay; Owner: -
--

CREATE TABLE infinitepay.webhook_logs (
    id uuid NOT NULL,
    external_id uuid,
    direction character varying(16) NOT NULL,
    kind character varying(64) NOT NULL,
    status_code integer,
    payload json NOT NULL,
    response json,
    source_ip character varying(64),
    user_agent text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: lead; Owner: -
--

CREATE TABLE lead.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: checkouts; Type: TABLE; Schema: lead; Owner: -
--

CREATE TABLE lead.checkouts (
    id bigint NOT NULL,
    external_id uuid NOT NULL,
    checkout_url character varying(1024),
    receipt_url character varying(1024),
    invoice_slug character varying(255),
    transaction_nsu character varying(255),
    capture_method character varying(50),
    installments smallint,
    is_paid boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    payment_method character varying(20),
    provider character varying(20),
    provider_payment_id character varying(255),
    qrcode_payload text,
    qrcode_image text,
    due_date date
);


--
-- Name: checkouts_id_seq; Type: SEQUENCE; Schema: lead; Owner: -
--

CREATE SEQUENCE lead.checkouts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: checkouts_id_seq; Type: SEQUENCE OWNED BY; Schema: lead; Owner: -
--

ALTER SEQUENCE lead.checkouts_id_seq OWNED BY lead.checkouts.id;


--
-- Name: leads; Type: TABLE; Schema: lead; Owner: -
--

CREATE TABLE lead.leads (
    id bigint NOT NULL,
    external_id uuid NOT NULL,
    status lead.lead_status DEFAULT 'captured'::lead.lead_status NOT NULL,
    promoter_external_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leads_id_seq; Type: SEQUENCE; Schema: lead; Owner: -
--

CREATE SEQUENCE lead.leads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: leads_id_seq; Type: SEQUENCE OWNED BY; Schema: lead; Owner: -
--

ALTER SEQUENCE lead.leads_id_seq OWNED BY lead.leads.id;


--
-- Name: messages; Type: TABLE; Schema: lead; Owner: -
--

CREATE TABLE lead.messages (
    id bigint NOT NULL,
    message_id integer,
    external_id uuid NOT NULL,
    direction character varying(10) DEFAULT 'out'::character varying NOT NULL,
    channel character varying(20),
    content text,
    status character varying(30),
    event character varying(50),
    meta jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: lead; Owner: -
--

CREATE SEQUENCE lead.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: lead; Owner: -
--

ALTER SEQUENCE lead.messages_id_seq OWNED BY lead.messages.id;


--
-- Name: alembic_version; Type: TABLE; Schema: notify; Owner: -
--

CREATE TABLE notify.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: contacts; Type: TABLE; Schema: notify; Owner: -
--

CREATE TABLE notify.contacts (
    id integer NOT NULL,
    external_id uuid NOT NULL,
    phone character varying(30),
    email character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: notify; Owner: -
--

CREATE SEQUENCE notify.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: notify; Owner: -
--

ALTER SEQUENCE notify.contacts_id_seq OWNED BY notify.contacts.id;


--
-- Name: logs; Type: TABLE; Schema: notify; Owner: -
--

CREATE TABLE notify.logs (
    id integer NOT NULL,
    message_id integer,
    action character varying(100) NOT NULL,
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    external_id uuid
);


--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: notify; Owner: -
--

CREATE SEQUENCE notify.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: notify; Owner: -
--

ALTER SEQUENCE notify.logs_id_seq OWNED BY notify.logs.id;


--
-- Name: messages; Type: TABLE; Schema: notify; Owner: -
--

CREATE TABLE notify.messages (
    id integer NOT NULL,
    contact_id integer NOT NULL,
    type character varying(20) NOT NULL,
    content_text text,
    whatsapp_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    email_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    email_subject character varying(255),
    tts_audio_url character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: notify; Owner: -
--

CREATE SEQUENCE notify.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: notify; Owner: -
--

ALTER SEQUENCE notify.messages_id_seq OWNED BY notify.messages.id;


--
-- Name: templates; Type: TABLE; Schema: notify; Owner: -
--

CREATE TABLE notify.templates (
    id integer NOT NULL,
    slug character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    html text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: templates_id_seq; Type: SEQUENCE; Schema: notify; Owner: -
--

CREATE SEQUENCE notify.templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: templates_id_seq; Type: SEQUENCE OWNED BY; Schema: notify; Owner: -
--

ALTER SEQUENCE notify.templates_id_seq OWNED BY notify.templates.id;


--
-- Name: alembic_version; Type: TABLE; Schema: otp; Owner: -
--

CREATE TABLE otp.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: otp_logs; Type: TABLE; Schema: otp; Owner: -
--

CREATE TABLE otp.otp_logs (
    id integer NOT NULL,
    external_id uuid NOT NULL,
    code_hash character varying(64) NOT NULL,
    status character varying(20) DEFAULT 'generated'::character varying NOT NULL,
    message_id integer,
    error_detail text,
    verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    failure_reason character varying(20)
);


--
-- Name: otp_logs_id_seq; Type: SEQUENCE; Schema: otp; Owner: -
--

CREATE SEQUENCE otp.otp_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: otp_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: otp; Owner: -
--

ALTER SEQUENCE otp.otp_logs_id_seq OWNED BY otp.otp_logs.id;


--
-- Name: pending_notify; Type: TABLE; Schema: otp; Owner: -
--

CREATE TABLE otp.pending_notify (
    id integer NOT NULL,
    external_id uuid NOT NULL,
    content text NOT NULL,
    otp_log_id integer NOT NULL,
    attempts integer DEFAULT 1 NOT NULL,
    next_retry_at timestamp with time zone NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    error_detail text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pending_notify_id_seq; Type: SEQUENCE; Schema: otp; Owner: -
--

CREATE SEQUENCE otp.pending_notify_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: pending_notify_id_seq; Type: SEQUENCE OWNED BY; Schema: otp; Owner: -
--

ALTER SEQUENCE otp.pending_notify_id_seq OWNED BY otp.pending_notify.id;


--
-- Name: rate_limit; Type: TABLE; Schema: otp; Owner: -
--

CREATE TABLE otp.rate_limit (
    external_id uuid NOT NULL,
    last_created_at timestamp with time zone NOT NULL,
    hourly_count integer DEFAULT 0 NOT NULL,
    hourly_window_start timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: profiles; Owner: -
--

CREATE TABLE profiles.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: birth_info; Type: TABLE; Schema: profiles; Owner: -
--

CREATE TABLE profiles.birth_info (
    id integer NOT NULL,
    profile_id integer NOT NULL,
    state character varying(2),
    city character varying(100),
    birth_date date
);


--
-- Name: birth_info_id_seq; Type: SEQUENCE; Schema: profiles; Owner: -
--

CREATE SEQUENCE profiles.birth_info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: birth_info_id_seq; Type: SEQUENCE OWNED BY; Schema: profiles; Owner: -
--

ALTER SEQUENCE profiles.birth_info_id_seq OWNED BY profiles.birth_info.id;


--
-- Name: educational; Type: TABLE; Schema: profiles; Owner: -
--

CREATE TABLE profiles.educational (
    id integer NOT NULL,
    profile_id integer NOT NULL,
    level character varying(30),
    last_elementary_year character varying(10),
    elementary_completed boolean,
    elementary_year integer,
    last_high_school_year character varying(15),
    high_school_completed boolean
);


--
-- Name: educational_id_seq; Type: SEQUENCE; Schema: profiles; Owner: -
--

CREATE SEQUENCE profiles.educational_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: educational_id_seq; Type: SEQUENCE OWNED BY; Schema: profiles; Owner: -
--

ALTER SEQUENCE profiles.educational_id_seq OWNED BY profiles.educational.id;


--
-- Name: profiles; Type: TABLE; Schema: profiles; Owner: -
--

CREATE TABLE profiles.profiles (
    id integer NOT NULL,
    external_id uuid NOT NULL,
    cpf character varying(11) NOT NULL,
    name character varying(200),
    gender character varying(1),
    mother_name character varying(200),
    father_name character varying(200),
    blood_type character varying(3),
    civil_status character varying(20),
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: profiles_id_seq; Type: SEQUENCE; Schema: profiles; Owner: -
--

CREATE SEQUENCE profiles.profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: profiles; Owner: -
--

ALTER SEQUENCE profiles.profiles_id_seq OWNED BY profiles.profiles.id;


--
-- Name: alembic_version; Type: TABLE; Schema: promoter; Owner: -
--

CREATE TABLE promoter.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: promoters; Type: TABLE; Schema: promoter; Owner: -
--

CREATE TABLE promoter.promoters (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    hub_external_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: roles; Owner: -
--

CREATE TABLE roles.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: role_rules; Type: TABLE; Schema: roles; Owner: -
--

CREATE TABLE roles.role_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    from_role character varying(64),
    to_role character varying(64) NOT NULL,
    mode character varying(16) NOT NULL,
    requires_role character varying(64),
    forbids_role character varying(64),
    blocking boolean DEFAULT false NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: roles; Owner: -
--

CREATE TABLE roles.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    external_id uuid NOT NULL,
    role character varying(64) NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: alembic_version; Type: TABLE; Schema: staff; Owner: -
--

CREATE TABLE staff.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: student; Owner: -
--

CREATE TABLE student.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: student_diplomas; Type: TABLE; Schema: student; Owner: -
--

CREATE TABLE student.student_diplomas (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    issued_by_external_id uuid,
    issued_at timestamp with time zone,
    picked_up_at timestamp with time zone,
    pickup_photo_external_id uuid,
    commission_triggered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: student_documents; Type: TABLE; Schema: student; Owner: -
--

CREATE TABLE student.student_documents (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    document_type character varying(40) NOT NULL,
    document_external_id uuid NOT NULL,
    validation_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    validation_result jsonb,
    validated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: student_exams; Type: TABLE; Schema: student; Owner: -
--

CREATE TABLE student.student_exams (
    id uuid NOT NULL,
    student_id uuid NOT NULL,
    subject character varying(80) NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    attempt_number integer DEFAULT 1 NOT NULL,
    result character varying(20),
    corrected_by_external_id uuid,
    corrected_at timestamp with time zone,
    notes character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: students; Type: TABLE; Schema: student; Owner: -
--

CREATE TABLE student.students (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    status character varying(40) NOT NULL,
    study_platform jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: training; Owner: -
--

CREATE TABLE training.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: materials; Type: TABLE; Schema: training; Owner: -
--

CREATE TABLE training.materials (
    id uuid NOT NULL,
    title character varying(200) NOT NULL,
    text_content text NOT NULL,
    question text NOT NULL,
    expected_answer text NOT NULL,
    video_path character varying(500),
    photo_path character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: submissions; Type: TABLE; Schema: training; Owner: -
--

CREATE TABLE training.submissions (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    material_id uuid NOT NULL,
    answer text NOT NULL,
    grade double precision,
    justification text,
    status character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: trainees; Type: TABLE; Schema: training; Owner: -
--

CREATE TABLE training.trainees (
    id uuid NOT NULL,
    external_id uuid NOT NULL,
    status character varying(32) NOT NULL,
    coordinator_external_id uuid,
    coordinator_decision_at timestamp with time zone,
    rejection_reason text,
    awaiting_interview_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: enrollment_events id; Type: DEFAULT; Schema: enrollment; Owner: -
--

ALTER TABLE ONLY enrollment.enrollment_events ALTER COLUMN id SET DEFAULT nextval('enrollment.enrollment_events_id_seq'::regclass);


--
-- Name: checkouts id; Type: DEFAULT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.checkouts ALTER COLUMN id SET DEFAULT nextval('lead.checkouts_id_seq'::regclass);


--
-- Name: leads id; Type: DEFAULT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.leads ALTER COLUMN id SET DEFAULT nextval('lead.leads_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.messages ALTER COLUMN id SET DEFAULT nextval('lead.messages_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.contacts ALTER COLUMN id SET DEFAULT nextval('notify.contacts_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.logs ALTER COLUMN id SET DEFAULT nextval('notify.logs_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.messages ALTER COLUMN id SET DEFAULT nextval('notify.messages_id_seq'::regclass);


--
-- Name: templates id; Type: DEFAULT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.templates ALTER COLUMN id SET DEFAULT nextval('notify.templates_id_seq'::regclass);


--
-- Name: otp_logs id; Type: DEFAULT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.otp_logs ALTER COLUMN id SET DEFAULT nextval('otp.otp_logs_id_seq'::regclass);


--
-- Name: pending_notify id; Type: DEFAULT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.pending_notify ALTER COLUMN id SET DEFAULT nextval('otp.pending_notify_id_seq'::regclass);


--
-- Name: birth_info id; Type: DEFAULT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.birth_info ALTER COLUMN id SET DEFAULT nextval('profiles.birth_info_id_seq'::regclass);


--
-- Name: educational id; Type: DEFAULT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.educational ALTER COLUMN id SET DEFAULT nextval('profiles.educational_id_seq'::regclass);


--
-- Name: profiles id; Type: DEFAULT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.profiles ALTER COLUMN id SET DEFAULT nextval('profiles.profiles_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: address; Owner: -
--

COPY address.alembic_version (version_num) FROM stdin;
0002
\.


--
-- Data for Name: addresses; Type: TABLE DATA; Schema: addresses; Owner: -
--

COPY addresses.addresses (id, external_id, kind, zipcode, street, number, complement, neighborhood, city, state, country, lat, lng, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: entity_address_details; Type: TABLE DATA; Schema: addresses; Owner: -
--

COPY addresses.entity_address_details (id, street, number, complement, neighborhood, city, state, zipcode, lat, lng, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: entity_addresses; Type: TABLE DATA; Schema: addresses; Owner: -
--

COPY addresses.entity_addresses (id, entity_type, external_id, proof_file, address_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: asaas; Owner: -
--

COPY asaas.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: asaas; Owner: -
--

COPY asaas.config (key, value, updated_at) FROM stdin;
asaas_api_key	CHANGE_ME	2026-05-28 00:08:15.445549+00
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: asaas; Owner: -
--

COPY asaas.customer (id, external_id, asaas_id, name, cpf_cnpj, email, mobile_phone, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: payment; Type: TABLE DATA; Schema: asaas; Owner: -
--

COPY asaas.payment (id, payment_id, kind, pixkey_external_id, qrcode_payload, customer_external_id, pix_qr_image, due_date, amount, description, scheduled_for, status, asaas_id, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pix_key; Type: TABLE DATA; Schema: asaas; Owner: -
--

COPY asaas.pix_key (id, external_id, key, key_type, holder_document, holder_name, bank_name, validated_at, raw_dict) FROM stdin;
\.


--
-- Data for Name: url_verify_nonce; Type: TABLE DATA; Schema: asaas; Owner: -
--

COPY asaas.url_verify_nonce (nonce, target_url, purpose, created_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: webhook_event; Type: TABLE DATA; Schema: asaas; Owner: -
--

COPY asaas.webhook_event (id, received_at, event, payload, forwarded_ok, forwarded_at, source_ip, user_agent) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.alembic_version (version_num) FROM stdin;
0007
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (id, user_id, token_hash, expires_at, revoked_at, family_id, created_at) FROM stdin;
\.


--
-- Data for Name: role_rules; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.role_rules (id, from_role, to_role, mode, requires_role, forbids_role, blocking) FROM stdin;
2a9e7b62-e0f0-433a-a5ef-5bad2bb32402	\N	a	add	\N	\N	f
d81cb625-91a2-487e-bb8e-b11ee62ff102	\N	x	add	\N	\N	f
d08df4fe-9570-41ea-941d-37ce7a51f7a5	a	b	replace	\N	\N	f
6cad4bea-cb42-4e5e-906c-802cd4c83792	x	y	replace	\N	\N	f
759feacf-c819-418b-ae8f-d33087816569	\N	c	add	b	\N	f
b6ef6850-f812-4fd2-9350-2743b199254a	\N	z	add	y	\N	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (id, external_id, created_at) FROM stdin;
2eafe3a1-d2c5-4312-8ace-f3974bc135ec	c5d00125-43d3-43fc-886d-89d2ddef7c49	2026-05-27 20:46:02.732216+00
9fe1a6c3-3aec-4c07-9380-3fa7c85b635b	caddcdfd-ab01-4c5a-8634-60e92cb6d295	2026-05-27 21:43:30.611356+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: candidate; Owner: -
--

COPY candidate.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: candidates; Type: TABLE DATA; Schema: candidate; Owner: -
--

COPY candidate.candidates (id, external_id, status, hub_external_id, created_at, updated_at) FROM stdin;
8b49c8a8-07da-4984-8336-ba81ba0766db	c5d00125-43d3-43fc-886d-89d2ddef7c49	captured	00000000-0000-0000-0000-000000000000	2026-05-27 20:46:02.778406+00	2026-05-27 20:46:02.778406+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: enrollment; Owner: -
--

COPY enrollment.alembic_version (version_num) FROM stdin;
0003
\.


--
-- Data for Name: educational_data; Type: TABLE DATA; Schema: enrollment; Owner: -
--

COPY enrollment.educational_data (id, enrollment_id, last_year_studied, last_year_date, last_school, created_at) FROM stdin;
\.


--
-- Data for Name: enrollment_events; Type: TABLE DATA; Schema: enrollment; Owner: -
--

COPY enrollment.enrollment_events (id, external_id, event, promoter_external_id, payload, received_at, processed_at) FROM stdin;
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: enrollment; Owner: -
--

COPY enrollment.enrollments (id, external_id, status, promoter_external_id, hub_external_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: fees; Owner: -
--

COPY fees.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: fee; Type: TABLE DATA; Schema: fees; Owner: -
--

COPY fees.fee (id, student_external_id, coordinator_external_id, status, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fee_payment; Type: TABLE DATA; Schema: fees; Owner: -
--

COPY fees.fee_payment (id, fee_id, kind, payment_id, qrcode_payload, amount, scheduled_date, status, asaas_id, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: hub; Owner: -
--

COPY hub.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: hub; Type: TABLE DATA; Schema: hub; Owner: -
--

COPY hub.hub (id, name, brand, address_external_id, coordinator_external_id, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	Polo Default	estacio	\N	\N	2026-05-27 20:32:06.04654+00	2026-05-27 20:32:06.04654+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: infinitepay; Owner: -
--

COPY infinitepay.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: checkouts; Type: TABLE DATA; Schema: infinitepay; Owner: -
--

COPY infinitepay.checkouts (id, external_id, checkout_url, is_paid, receipt_url, installments, invoice_slug, capture_method, transaction_nsu, request_payload, response_payload, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: outbound_jobs; Type: TABLE DATA; Schema: infinitepay; Owner: -
--

COPY infinitepay.outbound_jobs (id, url, payload, external_id, attempts, max_attempts, next_attempt_at, delivered_at, last_error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_logs; Type: TABLE DATA; Schema: infinitepay; Owner: -
--

COPY infinitepay.webhook_logs (id, external_id, direction, kind, status_code, payload, response, source_ip, user_agent, created_at) FROM stdin;
1dad601e-957a-4dee-9328-9e2a5924cfd4	caddcdfd-ab01-4c5a-8634-60e92cb6d295	outbound	create_link	200	{"handle": "v7m", "items": [{"quantity": 1, "price": 100, "description": "Material Did\\u00e1tico - Curso Supletivo"}], "order_nsu": "caddcdfd-ab01-4c5a-8634-60e92cb6d295", "redirect_url": "https://lead.supletivo.net", "webhook_url": "https://api.supletivo.net//api/v1/webhook/?external_id=gAAAAABqF2tq3Ciz3d6lJ2Z07nPlmeUzxeP48ImlHtmY0G3EglqmBPOnyv8jb0BrsW8xfdAsD2b6CryyPgBTOxPLcEL9vqEjcyjw_CBkPAhcDUvicQXE36Z0Wy4Xv4R6xrX17zMr0fY5", "customer": {"name": "Diandra Adelmaris de Freitas", "email": "diandra@example.com", "phone_number": "+5542999384069"}}	{"url": "https://checkout.infinitepay.io/v7m?lenc=GwQCIGRqTm_KoSsFsAxDTv6_XRDdWE9IBrebm1EdvAnsG75rs9-lhOPAEu4DpwlROrcRrM7iwMNvMjDtxWOW8uT2sJd_dUnQoS1MViBSNcGWnEmIJps2klzBuatf_0AvUr4PgAH0CoX3AcbvCZqmCH5OSY7CGP4bEO3Df7mvO954FggQAjiEKUHE8BQFaCHFMSSVYjDEE0BkIMHT9_o2Nz6r3bHiL08etVcTdwzM4Uupdjz7yLFVl-D_lSsBYzLVT2Bn2TNV5Eq-cS8U-0oMst0ZnvtqU7ja92z192uqoEckdeIf0jpyHwIkHhqGcnTjasf_Y0EwJYO7IePjmRCXKaFWCRZGlfUTVatJuBZZk2ISMmqX2MJYfUHV0GocogWK62hq29U2sRbZGKmWVl2Y1yOfk0WsajvrXDiEFadOiEzNjqKFUXVlPlzog0af962GDCI52K9VlYXKIaiv-hJY3GiQzBa2HlEbPrXEhPYGzsYDGxtu0g.v1.6387c9ce1f091832"}	\N	\N	2026-05-27 22:08:43.46829+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: lead; Owner: -
--

COPY lead.alembic_version (version_num) FROM stdin;
0002
\.


--
-- Data for Name: checkouts; Type: TABLE DATA; Schema: lead; Owner: -
--

COPY lead.checkouts (id, external_id, checkout_url, receipt_url, invoice_slug, transaction_nsu, capture_method, installments, is_paid, created_at, updated_at, payment_method, provider, provider_payment_id, qrcode_payload, qrcode_image, due_date) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: lead; Owner: -
--

COPY lead.leads (id, external_id, status, promoter_external_id, created_at, updated_at) FROM stdin;
1	caddcdfd-ab01-4c5a-8634-60e92cb6d295	waiting	00000000-0000-0000-0000-000000000000	2026-05-27 21:43:30.675733+00	2026-05-27 22:02:20.251612+00
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: lead; Owner: -
--

COPY lead.messages (id, message_id, external_id, direction, channel, content, status, event, meta, created_at, updated_at) FROM stdin;
2	3	caddcdfd-ab01-4c5a-8634-60e92cb6d295	in	text	\N	sent	message.processed	{"contact_id": 2, "email_status": "skipped", "email_subject": "Olá, Diandra!", "tts_audio_url": null, "whatsapp_status": "sent"}	2026-05-27 21:43:33.326739+00	2026-05-27 21:43:33.326742+00
1	3	caddcdfd-ab01-4c5a-8634-60e92cb6d295	out	whatsapp	# Olá, Diandra!\n\nQue bom ter você com a gente!\n\nSeu cadastro está pronto, Diandra — falta só um passo pra garantir sua vaga no Supletivo: confirmar o pagamento.\n\nOlha, esse momento importa de verdade. Concluir os estudos abre portas: você passa a poder prestar concurso, ir atrás de uma vaga melhor, entrar numa faculdade. É um investimento que muda a sua vida — e a da sua família também.\n\nE uma coisa importante, Diandra: o preço atual pode subir a qualquer momento. Por isso, conclua o pagamento o quanto antes, garanta seu valor e comece a estudar logo, então bora juntos Diandra\n	sent	lead_captured	\N	2026-05-27 21:43:32.717948+00	2026-05-27 21:43:33.32683+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: notify; Owner: -
--

COPY notify.alembic_version (version_num) FROM stdin;
0003
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: notify; Owner: -
--

COPY notify.contacts (id, external_id, phone, email, created_at, updated_at) FROM stdin;
2	caddcdfd-ab01-4c5a-8634-60e92cb6d295	5542999384069	diandra@example.com	2026-05-27 21:43:31.347544+00	2026-05-27 22:02:20.334773+00
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: notify; Owner: -
--

COPY notify.logs (id, message_id, action, details, created_at, external_id) FROM stdin;
1	\N	contact.created	{"has_email": false, "external_id": "c5d00125-43d3-43fc-886d-89d2ddef7c49", "phone_original": "42999384069", "phone_normalized": "5542999384069"}	2026-05-27 20:46:03.581871+00	c5d00125-43d3-43fc-886d-89d2ddef7c49
4	\N	contact.created	{"has_email": false, "external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295", "phone_original": "42999384069", "phone_normalized": "5542999384069"}	2026-05-27 21:43:31.347544+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
5	2	message.created	{"flags": {"ai": false, "img": false, "tts": false}, "title": "Código de Verificação", "has_webhook": true, "template_slug": null, "contact_external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295"}	2026-05-27 21:43:31.44244+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
6	2	message.sent	{"ai": false, "img": false, "tts": false, "type": "text", "email": "skipped", "media": null, "whatsapp": "sent", "tts_fallback": null, "template_slug": "default", "whatsapp_error": null, "template_version": 1, "whatsapp_attempts": 1, "contact_external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295", "tts_fallback_reason": null}	2026-05-27 21:43:31.447377+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
7	3	message.created	{"flags": {"ai": false, "img": false, "tts": true}, "title": null, "has_webhook": true, "template_slug": null, "contact_external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295"}	2026-05-27 21:43:32.708082+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
8	3	message.sent	{"ai": false, "img": false, "tts": true, "type": "text", "email": "skipped", "media": null, "whatsapp": "sent", "tts_fallback": true, "template_slug": "default", "whatsapp_error": null, "template_version": 1, "whatsapp_attempts": 1, "contact_external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295", "tts_fallback_reason": "generation: IntegrationError"}	2026-05-27 21:43:32.714859+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
9	4	message.created	{"flags": {"ai": false, "img": false, "tts": false}, "title": "Código de Verificação", "has_webhook": true, "template_slug": null, "contact_external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295"}	2026-05-27 22:00:40.892679+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
10	4	message.sent	{"ai": false, "img": false, "tts": false, "type": "text", "email": "skipped", "media": null, "whatsapp": "sent", "tts_fallback": null, "template_slug": "default", "whatsapp_error": null, "template_version": 1, "whatsapp_attempts": 1, "contact_external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295", "tts_fallback_reason": null}	2026-05-27 22:00:40.899472+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
11	\N	contact.email_updated	{"email": "diandra@example.com", "external_id": "caddcdfd-ab01-4c5a-8634-60e92cb6d295"}	2026-05-27 22:02:20.334773+00	caddcdfd-ab01-4c5a-8634-60e92cb6d295
12	\N	email.test_failed	{"error": "SMTPServerDisconnected: SMTPServerDisconnected('please run connect() first')", "to_email": "victormaestri@gmail.com", "smtp_response": null, "template_slug": "default", "template_version": 1}	2026-05-27 22:13:55.856464+00	\N
13	\N	email.test_sent	{"error": null, "to_email": "victormaestri@gmail.com", "smtp_response": {"to": "victormaestri@gmail.com", "from": "notify <v7maestri@gmail.com>", "refused": {}, "subject": "Teste notify — via servico"}, "template_slug": "default", "template_version": 1}	2026-05-27 22:20:51.553935+00	\N
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: notify; Owner: -
--

COPY notify.messages (id, contact_id, type, content_text, whatsapp_status, email_status, email_subject, tts_audio_url, created_at, updated_at) FROM stdin;
2	2	text	Olá! Seu código de acesso é:\n\n*085955*\n\nVálido por *5 minutos*. Não compartilhe com ninguém.\n	sent	skipped	Código de Verificação	\N	2026-05-27 21:43:31.44244+00	2026-05-27 21:43:31.447377+00
3	2	text	# Olá, Diandra!\n\nQue bom ter você com a gente!\n\nSeu cadastro está pronto, Diandra — falta só um passo pra garantir sua vaga no Supletivo: confirmar o pagamento.\n\nOlha, esse momento importa de verdade. Concluir os estudos abre portas: você passa a poder prestar concurso, ir atrás de uma vaga melhor, entrar numa faculdade. É um investimento que muda a sua vida — e a da sua família também.\n\nE uma coisa importante, Diandra: o preço atual pode subir a qualquer momento. Por isso, conclua o pagamento o quanto antes, garanta seu valor e comece a estudar logo, então bora juntos Diandra\n	sent	skipped	Olá, Diandra!	\N	2026-05-27 21:43:32.708082+00	2026-05-27 21:43:32.714859+00
4	2	text	Olá! Seu código de acesso é:\n\n*978415*\n\nVálido por *5 minutos*. Não compartilhe com ninguém.\n	sent	skipped	Código de Verificação	\N	2026-05-27 22:00:40.892679+00	2026-05-27 22:00:40.899472+00
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: notify; Owner: -
--

COPY notify.templates (id, slug, name, html, version, is_active, created_at, updated_at) FROM stdin;
1	default	Template padrao	<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n</head>\n<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:Arial,sans-serif">\n  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f4;padding:20px 0">\n    <tr>\n      <td align="center">\n        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;overflow:hidden">\n          <tr>\n            <td style="padding:40px 48px">\n              <h1 style="margin:0 0 16px;color:#1a1a1a;font-size:24px">{{title}}</h1>\n              <div style="color:#333333;font-size:16px;line-height:1.6">\n                {{content}}\n              </div>\n            </td>\n          </tr>\n          <tr>\n            <td style="padding:24px 48px;background-color:#f8f9fa;border-top:1px solid #e9ecef">\n              <p style="margin:0;color:#6c757d;font-size:12px">\n                supletivo.net.br\n              </p>\n            </td>\n          </tr>\n        </table>\n      </td>\n    </tr>\n  </table>\n</body>\n</html>\n	1	t	2026-05-27 20:39:26.032645+00	2026-05-27 20:39:26.032645+00
2	welcome	Boas-vindas	<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n</head>\n<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:Arial,sans-serif">\n  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f4;padding:20px 0">\n    <tr>\n      <td align="center">\n        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;overflow:hidden;border-top:4px solid #1a73e8">\n          <tr>\n            <td style="padding:40px 48px">\n              <h1 style="margin:0 0 16px;color:#1a73e8;font-size:24px">{{title}}</h1>\n              <div style="color:#333333;font-size:16px;line-height:1.6">\n                {{content}}\n              </div>\n            </td>\n          </tr>\n          <tr>\n            <td style="padding:24px 48px;background-color:#f8f9fa;border-top:1px solid #e9ecef">\n              <p style="margin:0;color:#6c757d;font-size:12px">\n                Bem-vindo(a) · supletivo.net.br\n              </p>\n            </td>\n          </tr>\n        </table>\n      </td>\n    </tr>\n  </table>\n</body>\n</html>\n	1	t	2026-05-27 20:39:26.032645+00	2026-05-27 20:39:26.032645+00
3	checkout	Link de checkout	<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n</head>\n<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:Arial,sans-serif">\n  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f4;padding:20px 0">\n    <tr>\n      <td align="center">\n        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;overflow:hidden;border-top:4px solid #d97706">\n          <tr>\n            <td style="padding:40px 48px">\n              <h1 style="margin:0 0 16px;color:#d97706;font-size:24px">{{title}}</h1>\n              <div style="color:#333333;font-size:16px;line-height:1.6">\n                {{content}}\n              </div>\n            </td>\n          </tr>\n          <tr>\n            <td style="padding:24px 48px;background-color:#f8f9fa;border-top:1px solid #e9ecef">\n              <p style="margin:0;color:#6c757d;font-size:12px">\n                Finalize sua compra · supletivo.net.br\n              </p>\n            </td>\n          </tr>\n        </table>\n      </td>\n    </tr>\n  </table>\n</body>\n</html>\n	1	t	2026-05-27 20:39:26.032645+00	2026-05-27 20:39:26.032645+00
4	receipt	Recibo de pagamento	<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n</head>\n<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:Arial,sans-serif">\n  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f4;padding:20px 0">\n    <tr>\n      <td align="center">\n        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;overflow:hidden;border-top:4px solid #16a34a">\n          <tr>\n            <td style="padding:40px 48px">\n              <h1 style="margin:0 0 16px;color:#16a34a;font-size:24px">{{title}}</h1>\n              <div style="color:#333333;font-size:16px;line-height:1.6">\n                {{content}}\n              </div>\n            </td>\n          </tr>\n          <tr>\n            <td style="padding:24px 48px;background-color:#f8f9fa;border-top:1px solid #e9ecef">\n              <p style="margin:0;color:#6c757d;font-size:12px">\n                Pagamento confirmado · supletivo.net.br\n              </p>\n            </td>\n          </tr>\n        </table>\n      </td>\n    </tr>\n  </table>\n</body>\n</html>\n	1	t	2026-05-27 20:39:26.032645+00	2026-05-27 20:39:26.032645+00
5	parabens	Parabens / celebracao	<!DOCTYPE html>\n<html lang="pt-BR">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n</head>\n<body style="margin:0;padding:0;background-color:#f4f4f4;font-family:Arial,sans-serif">\n  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f4f4;padding:20px 0">\n    <tr>\n      <td align="center">\n        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff;border-radius:8px;overflow:hidden;border-top:4px solid #7c3aed">\n          <tr>\n            <td style="padding:40px 48px">\n              <h1 style="margin:0 0 16px;color:#7c3aed;font-size:24px">{{title}}</h1>\n              <div style="color:#333333;font-size:16px;line-height:1.6">\n                {{content}}\n              </div>\n            </td>\n          </tr>\n          <tr>\n            <td style="padding:24px 48px;background-color:#f8f9fa;border-top:1px solid #e9ecef">\n              <p style="margin:0;color:#6c757d;font-size:12px">\n                Voce conseguiu! · supletivo.net.br\n              </p>\n            </td>\n          </tr>\n        </table>\n      </td>\n    </tr>\n  </table>\n</body>\n</html>\n	1	t	2026-05-27 20:39:26.032645+00	2026-05-27 20:39:26.032645+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: otp; Owner: -
--

COPY otp.alembic_version (version_num) FROM stdin;
0002
\.


--
-- Data for Name: otp_logs; Type: TABLE DATA; Schema: otp; Owner: -
--

COPY otp.otp_logs (id, external_id, code_hash, status, message_id, error_detail, verified_at, created_at, attempts, failure_reason) FROM stdin;
1	c5d00125-43d3-43fc-886d-89d2ddef7c49	697de6a41cded9e8be7076fa768504f75b1d3e6e258f559020aa3a66c1d8b17a	verified	1	\N	2026-05-27 20:49:39.532143+00	2026-05-27 20:46:03.688929+00	0	\N
2	caddcdfd-ab01-4c5a-8634-60e92cb6d295	921ac064c96d1cfd529171085e8e38fc30ab01c0ce82bec62f7b02b687846c35	verified	2	\N	2026-05-27 21:45:54.715326+00	2026-05-27 21:43:31.435986+00	0	\N
3	caddcdfd-ab01-4c5a-8634-60e92cb6d295	c47d4fd108cbca84f9085cd601c42eb0a249fb86aad044d04593603526b04458	verified	4	\N	2026-05-27 22:02:06.273933+00	2026-05-27 22:00:40.880576+00	0	\N
\.


--
-- Data for Name: pending_notify; Type: TABLE DATA; Schema: otp; Owner: -
--

COPY otp.pending_notify (id, external_id, content, otp_log_id, attempts, next_retry_at, status, error_detail, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rate_limit; Type: TABLE DATA; Schema: otp; Owner: -
--

COPY otp.rate_limit (external_id, last_created_at, hourly_count, hourly_window_start, updated_at) FROM stdin;
c5d00125-43d3-43fc-886d-89d2ddef7c49	2026-05-27 20:46:03.682493+00	1	2026-05-27 20:46:03.682493+00	2026-05-27 20:46:03.683998+00
caddcdfd-ab01-4c5a-8634-60e92cb6d295	2026-05-27 22:00:40.872355+00	2	2026-05-27 21:43:31.430445+00	2026-05-27 21:43:31.431166+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: profiles; Owner: -
--

COPY profiles.alembic_version (version_num) FROM stdin;
0003
\.


--
-- Data for Name: birth_info; Type: TABLE DATA; Schema: profiles; Owner: -
--

COPY profiles.birth_info (id, profile_id, state, city, birth_date) FROM stdin;
2	2	\N	\N	1990-12-15
\.


--
-- Data for Name: educational; Type: TABLE DATA; Schema: profiles; Owner: -
--

COPY profiles.educational (id, profile_id, level, last_elementary_year, elementary_completed, elementary_year, last_high_school_year, high_school_completed) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: profiles; Owner: -
--

COPY profiles.profiles (id, external_id, cpf, name, gender, mother_name, father_name, blood_type, civil_status, description, created_at, updated_at) FROM stdin;
2	caddcdfd-ab01-4c5a-8634-60e92cb6d295	07461638947	Diandra Adelmaris de Freitas	F	\N	\N	\N	\N	\N	2026-05-27 21:43:30.666553+00	2026-05-27 21:43:30.669067+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: promoter; Owner: -
--

COPY promoter.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: promoters; Type: TABLE DATA; Schema: promoter; Owner: -
--

COPY promoter.promoters (id, external_id, status, hub_external_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: roles; Owner: -
--

COPY roles.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: role_rules; Type: TABLE DATA; Schema: roles; Owner: -
--

COPY roles.role_rules (id, from_role, to_role, mode, requires_role, forbids_role, blocking) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: roles; Owner: -
--

COPY roles.user_roles (id, external_id, role, assigned_at, revoked_at) FROM stdin;
5db618a8-cb36-492a-a1b6-61d184ce92d7	c5d00125-43d3-43fc-886d-89d2ddef7c49	lead	2026-05-27 20:46:02.778476+00	\N
890dbb9d-b999-4902-8311-08c6f6611e59	caddcdfd-ab01-4c5a-8634-60e92cb6d295	lead	2026-05-27 21:43:30.650497+00	\N
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: staff; Owner: -
--

COPY staff.alembic_version (version_num) FROM stdin;
0001
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: student; Owner: -
--

COPY student.alembic_version (version_num) FROM stdin;
0002
\.


--
-- Data for Name: student_diplomas; Type: TABLE DATA; Schema: student; Owner: -
--

COPY student.student_diplomas (id, student_id, issued_by_external_id, issued_at, picked_up_at, pickup_photo_external_id, commission_triggered_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_documents; Type: TABLE DATA; Schema: student; Owner: -
--

COPY student.student_documents (id, student_id, document_type, document_external_id, validation_status, validation_result, validated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: student_exams; Type: TABLE DATA; Schema: student; Owner: -
--

COPY student.student_exams (id, student_id, subject, scheduled_at, attempt_number, result, corrected_by_external_id, corrected_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: student; Owner: -
--

COPY student.students (id, external_id, status, study_platform, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: training; Owner: -
--

COPY training.alembic_version (version_num) FROM stdin;
0002
\.


--
-- Data for Name: materials; Type: TABLE DATA; Schema: training; Owner: -
--

COPY training.materials (id, title, text_content, question, expected_answer, video_path, photo_path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: training; Owner: -
--

COPY training.submissions (id, external_id, material_id, answer, grade, justification, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: trainees; Type: TABLE DATA; Schema: training; Owner: -
--

COPY training.trainees (id, external_id, status, coordinator_external_id, coordinator_decision_at, rejection_reason, awaiting_interview_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: enrollment_events_id_seq; Type: SEQUENCE SET; Schema: enrollment; Owner: -
--

SELECT pg_catalog.setval('enrollment.enrollment_events_id_seq', 1, false);


--
-- Name: checkouts_id_seq; Type: SEQUENCE SET; Schema: lead; Owner: -
--

SELECT pg_catalog.setval('lead.checkouts_id_seq', 1, false);


--
-- Name: leads_id_seq; Type: SEQUENCE SET; Schema: lead; Owner: -
--

SELECT pg_catalog.setval('lead.leads_id_seq', 1, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: lead; Owner: -
--

SELECT pg_catalog.setval('lead.messages_id_seq', 2, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: notify; Owner: -
--

SELECT pg_catalog.setval('notify.contacts_id_seq', 2, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: notify; Owner: -
--

SELECT pg_catalog.setval('notify.logs_id_seq', 13, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: notify; Owner: -
--

SELECT pg_catalog.setval('notify.messages_id_seq', 4, true);


--
-- Name: templates_id_seq; Type: SEQUENCE SET; Schema: notify; Owner: -
--

SELECT pg_catalog.setval('notify.templates_id_seq', 5, true);


--
-- Name: otp_logs_id_seq; Type: SEQUENCE SET; Schema: otp; Owner: -
--

SELECT pg_catalog.setval('otp.otp_logs_id_seq', 3, true);


--
-- Name: pending_notify_id_seq; Type: SEQUENCE SET; Schema: otp; Owner: -
--

SELECT pg_catalog.setval('otp.pending_notify_id_seq', 1, false);


--
-- Name: birth_info_id_seq; Type: SEQUENCE SET; Schema: profiles; Owner: -
--

SELECT pg_catalog.setval('profiles.birth_info_id_seq', 2, true);


--
-- Name: educational_id_seq; Type: SEQUENCE SET; Schema: profiles; Owner: -
--

SELECT pg_catalog.setval('profiles.educational_id_seq', 1, false);


--
-- Name: profiles_id_seq; Type: SEQUENCE SET; Schema: profiles; Owner: -
--

SELECT pg_catalog.setval('profiles.profiles_id_seq', 2, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: address; Owner: -
--

ALTER TABLE ONLY address.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: addresses; Owner: -
--

ALTER TABLE ONLY addresses.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: entity_address_details entity_address_details_pkey; Type: CONSTRAINT; Schema: addresses; Owner: -
--

ALTER TABLE ONLY addresses.entity_address_details
    ADD CONSTRAINT entity_address_details_pkey PRIMARY KEY (id);


--
-- Name: entity_addresses entity_addresses_entity_key; Type: CONSTRAINT; Schema: addresses; Owner: -
--

ALTER TABLE ONLY addresses.entity_addresses
    ADD CONSTRAINT entity_addresses_entity_key UNIQUE (entity_type, external_id);


--
-- Name: entity_addresses entity_addresses_pkey; Type: CONSTRAINT; Schema: addresses; Owner: -
--

ALTER TABLE ONLY addresses.entity_addresses
    ADD CONSTRAINT entity_addresses_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (key);


--
-- Name: customer customer_asaas_id_key; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.customer
    ADD CONSTRAINT customer_asaas_id_key UNIQUE (asaas_id);


--
-- Name: customer customer_external_id_key; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.customer
    ADD CONSTRAINT customer_external_id_key UNIQUE (external_id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: payment payment_payment_id_key; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.payment
    ADD CONSTRAINT payment_payment_id_key UNIQUE (payment_id);


--
-- Name: payment payment_pkey; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (id);


--
-- Name: pix_key pix_key_external_id_key; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.pix_key
    ADD CONSTRAINT pix_key_external_id_key UNIQUE (external_id);


--
-- Name: pix_key pix_key_key_key; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.pix_key
    ADD CONSTRAINT pix_key_key_key UNIQUE (key);


--
-- Name: pix_key pix_key_pkey; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.pix_key
    ADD CONSTRAINT pix_key_pkey PRIMARY KEY (id);


--
-- Name: url_verify_nonce url_verify_nonce_pkey; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.url_verify_nonce
    ADD CONSTRAINT url_verify_nonce_pkey PRIMARY KEY (nonce);


--
-- Name: webhook_event webhook_event_pkey; Type: CONSTRAINT; Schema: asaas; Owner: -
--

ALTER TABLE ONLY asaas.webhook_event
    ADD CONSTRAINT webhook_event_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: role_rules role_rules_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.role_rules
    ADD CONSTRAINT role_rules_pkey PRIMARY KEY (id);


--
-- Name: users users_id_external_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_id_external_key UNIQUE (external_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: candidate; Owner: -
--

ALTER TABLE ONLY candidate.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: candidates candidates_external_id_key; Type: CONSTRAINT; Schema: candidate; Owner: -
--

ALTER TABLE ONLY candidate.candidates
    ADD CONSTRAINT candidates_external_id_key UNIQUE (external_id);


--
-- Name: candidates candidates_pkey; Type: CONSTRAINT; Schema: candidate; Owner: -
--

ALTER TABLE ONLY candidate.candidates
    ADD CONSTRAINT candidates_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: enrollment; Owner: -
--

ALTER TABLE ONLY enrollment.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: educational_data educational_data_enrollment_id_key; Type: CONSTRAINT; Schema: enrollment; Owner: -
--

ALTER TABLE ONLY enrollment.educational_data
    ADD CONSTRAINT educational_data_enrollment_id_key UNIQUE (enrollment_id);


--
-- Name: educational_data educational_data_pkey; Type: CONSTRAINT; Schema: enrollment; Owner: -
--

ALTER TABLE ONLY enrollment.educational_data
    ADD CONSTRAINT educational_data_pkey PRIMARY KEY (id);


--
-- Name: enrollment_events enrollment_events_pkey; Type: CONSTRAINT; Schema: enrollment; Owner: -
--

ALTER TABLE ONLY enrollment.enrollment_events
    ADD CONSTRAINT enrollment_events_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: enrollment; Owner: -
--

ALTER TABLE ONLY enrollment.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: fees; Owner: -
--

ALTER TABLE ONLY fees.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: fee_payment fee_payment_pkey; Type: CONSTRAINT; Schema: fees; Owner: -
--

ALTER TABLE ONLY fees.fee_payment
    ADD CONSTRAINT fee_payment_pkey PRIMARY KEY (id);


--
-- Name: fee fee_pkey; Type: CONSTRAINT; Schema: fees; Owner: -
--

ALTER TABLE ONLY fees.fee
    ADD CONSTRAINT fee_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: hub; Owner: -
--

ALTER TABLE ONLY hub.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: hub hub_pkey; Type: CONSTRAINT; Schema: hub; Owner: -
--

ALTER TABLE ONLY hub.hub
    ADD CONSTRAINT hub_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: checkouts checkouts_external_id_key; Type: CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.checkouts
    ADD CONSTRAINT checkouts_external_id_key UNIQUE (external_id);


--
-- Name: checkouts checkouts_pkey; Type: CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.checkouts
    ADD CONSTRAINT checkouts_pkey PRIMARY KEY (id);


--
-- Name: outbound_jobs outbound_jobs_pkey; Type: CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.outbound_jobs
    ADD CONSTRAINT outbound_jobs_pkey PRIMARY KEY (id);


--
-- Name: webhook_logs webhook_logs_pkey; Type: CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.webhook_logs
    ADD CONSTRAINT webhook_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: checkouts checkouts_external_id_key; Type: CONSTRAINT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.checkouts
    ADD CONSTRAINT checkouts_external_id_key UNIQUE (external_id);


--
-- Name: checkouts checkouts_pkey; Type: CONSTRAINT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.checkouts
    ADD CONSTRAINT checkouts_pkey PRIMARY KEY (id);


--
-- Name: leads leads_external_id_key; Type: CONSTRAINT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.leads
    ADD CONSTRAINT leads_external_id_key UNIQUE (external_id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: lead; Owner: -
--

ALTER TABLE ONLY lead.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: contacts contacts_email_key; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.contacts
    ADD CONSTRAINT contacts_email_key UNIQUE (email);


--
-- Name: contacts contacts_external_id_key; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.contacts
    ADD CONSTRAINT contacts_external_id_key UNIQUE (external_id);


--
-- Name: contacts contacts_phone_key; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.contacts
    ADD CONSTRAINT contacts_phone_key UNIQUE (phone);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: templates templates_slug_key; Type: CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.templates
    ADD CONSTRAINT templates_slug_key UNIQUE (slug);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: otp_logs otp_logs_pkey; Type: CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.otp_logs
    ADD CONSTRAINT otp_logs_pkey PRIMARY KEY (id);


--
-- Name: pending_notify pending_notify_pkey; Type: CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.pending_notify
    ADD CONSTRAINT pending_notify_pkey PRIMARY KEY (id);


--
-- Name: rate_limit rate_limit_pkey; Type: CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.rate_limit
    ADD CONSTRAINT rate_limit_pkey PRIMARY KEY (external_id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: birth_info birth_info_pkey; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.birth_info
    ADD CONSTRAINT birth_info_pkey PRIMARY KEY (id);


--
-- Name: birth_info birth_info_profile_id_key; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.birth_info
    ADD CONSTRAINT birth_info_profile_id_key UNIQUE (profile_id);


--
-- Name: educational educational_pkey; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.educational
    ADD CONSTRAINT educational_pkey PRIMARY KEY (id);


--
-- Name: educational educational_profile_id_key; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.educational
    ADD CONSTRAINT educational_profile_id_key UNIQUE (profile_id);


--
-- Name: profiles profiles_cpf_key; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.profiles
    ADD CONSTRAINT profiles_cpf_key UNIQUE (cpf);


--
-- Name: profiles profiles_external_id_key; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.profiles
    ADD CONSTRAINT profiles_external_id_key UNIQUE (external_id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: promoter; Owner: -
--

ALTER TABLE ONLY promoter.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: promoters promoters_external_id_key; Type: CONSTRAINT; Schema: promoter; Owner: -
--

ALTER TABLE ONLY promoter.promoters
    ADD CONSTRAINT promoters_external_id_key UNIQUE (external_id);


--
-- Name: promoters promoters_pkey; Type: CONSTRAINT; Schema: promoter; Owner: -
--

ALTER TABLE ONLY promoter.promoters
    ADD CONSTRAINT promoters_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: roles; Owner: -
--

ALTER TABLE ONLY roles.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: role_rules role_rules_pkey; Type: CONSTRAINT; Schema: roles; Owner: -
--

ALTER TABLE ONLY roles.role_rules
    ADD CONSTRAINT role_rules_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: roles; Owner: -
--

ALTER TABLE ONLY roles.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: staff; Owner: -
--

ALTER TABLE ONLY staff.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: student_diplomas student_diplomas_pkey; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_diplomas
    ADD CONSTRAINT student_diplomas_pkey PRIMARY KEY (id);


--
-- Name: student_diplomas student_diplomas_student_id_key; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_diplomas
    ADD CONSTRAINT student_diplomas_student_id_key UNIQUE (student_id);


--
-- Name: student_documents student_documents_pkey; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_documents
    ADD CONSTRAINT student_documents_pkey PRIMARY KEY (id);


--
-- Name: student_documents student_documents_student_type_key; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_documents
    ADD CONSTRAINT student_documents_student_type_key UNIQUE (student_id, document_type);


--
-- Name: student_exams student_exams_pkey; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_exams
    ADD CONSTRAINT student_exams_pkey PRIMARY KEY (id);


--
-- Name: students students_external_id_key; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.students
    ADD CONSTRAINT students_external_id_key UNIQUE (external_id);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: training; Owner: -
--

ALTER TABLE ONLY training.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: materials materials_pkey; Type: CONSTRAINT; Schema: training; Owner: -
--

ALTER TABLE ONLY training.materials
    ADD CONSTRAINT materials_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: training; Owner: -
--

ALTER TABLE ONLY training.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (id);


--
-- Name: trainees trainees_external_id_key; Type: CONSTRAINT; Schema: training; Owner: -
--

ALTER TABLE ONLY training.trainees
    ADD CONSTRAINT trainees_external_id_key UNIQUE (external_id);


--
-- Name: trainees trainees_pkey; Type: CONSTRAINT; Schema: training; Owner: -
--

ALTER TABLE ONLY training.trainees
    ADD CONSTRAINT trainees_pkey PRIMARY KEY (id);


--
-- Name: addresses_external_id_idx; Type: INDEX; Schema: addresses; Owner: -
--

CREATE INDEX addresses_external_id_idx ON addresses.addresses USING btree (external_id);


--
-- Name: addresses_external_id_kind_idx; Type: INDEX; Schema: addresses; Owner: -
--

CREATE INDEX addresses_external_id_kind_idx ON addresses.addresses USING btree (external_id, kind);


--
-- Name: addresses_kind_idx; Type: INDEX; Schema: addresses; Owner: -
--

CREATE INDEX addresses_kind_idx ON addresses.addresses USING btree (kind);


--
-- Name: addresses_zipcode_idx; Type: INDEX; Schema: addresses; Owner: -
--

CREATE INDEX addresses_zipcode_idx ON addresses.addresses USING btree (zipcode);


--
-- Name: ix_customer_asaas_id; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_customer_asaas_id ON asaas.customer USING btree (asaas_id);


--
-- Name: ix_customer_cpf_cnpj; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_customer_cpf_cnpj ON asaas.customer USING btree (cpf_cnpj);


--
-- Name: ix_customer_external_id; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_customer_external_id ON asaas.customer USING btree (external_id);


--
-- Name: ix_payment_asaas_id; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_payment_asaas_id ON asaas.payment USING btree (asaas_id);


--
-- Name: ix_payment_customer_external_id; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_payment_customer_external_id ON asaas.payment USING btree (customer_external_id);


--
-- Name: ix_payment_kind; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_payment_kind ON asaas.payment USING btree (kind);


--
-- Name: ix_payment_payment_id; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_payment_payment_id ON asaas.payment USING btree (payment_id);


--
-- Name: ix_payment_pixkey_external_id; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_payment_pixkey_external_id ON asaas.payment USING btree (pixkey_external_id);


--
-- Name: ix_payment_status; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_payment_status ON asaas.payment USING btree (status);


--
-- Name: ix_pix_key_external_id; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_pix_key_external_id ON asaas.pix_key USING btree (external_id);


--
-- Name: ix_pix_key_holder_document; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_pix_key_holder_document ON asaas.pix_key USING btree (holder_document);


--
-- Name: ix_pix_key_key; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_pix_key_key ON asaas.pix_key USING btree (key);


--
-- Name: ix_webhook_event_event; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_webhook_event_event ON asaas.webhook_event USING btree (event);


--
-- Name: ix_webhook_event_received_at; Type: INDEX; Schema: asaas; Owner: -
--

CREATE INDEX ix_webhook_event_received_at ON asaas.webhook_event USING btree (received_at);


--
-- Name: auth_refresh_tokens_identity_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX auth_refresh_tokens_identity_id_idx ON auth.refresh_tokens USING btree (user_id);


--
-- Name: candidates_external_id_idx; Type: INDEX; Schema: candidate; Owner: -
--

CREATE UNIQUE INDEX candidates_external_id_idx ON candidate.candidates USING btree (external_id);


--
-- Name: candidates_hub_external_id_idx; Type: INDEX; Schema: candidate; Owner: -
--

CREATE INDEX candidates_hub_external_id_idx ON candidate.candidates USING btree (hub_external_id);


--
-- Name: candidates_status_idx; Type: INDEX; Schema: candidate; Owner: -
--

CREATE INDEX candidates_status_idx ON candidate.candidates USING btree (status);


--
-- Name: enrollment_events_event_idx; Type: INDEX; Schema: enrollment; Owner: -
--

CREATE INDEX enrollment_events_event_idx ON enrollment.enrollment_events USING btree (event);


--
-- Name: enrollment_events_external_id_idx; Type: INDEX; Schema: enrollment; Owner: -
--

CREATE INDEX enrollment_events_external_id_idx ON enrollment.enrollment_events USING btree (external_id);


--
-- Name: enrollment_events_promoter_external_id_idx; Type: INDEX; Schema: enrollment; Owner: -
--

CREATE INDEX enrollment_events_promoter_external_id_idx ON enrollment.enrollment_events USING btree (promoter_external_id);


--
-- Name: enrollments_external_id_idx; Type: INDEX; Schema: enrollment; Owner: -
--

CREATE UNIQUE INDEX enrollments_external_id_idx ON enrollment.enrollments USING btree (external_id);


--
-- Name: enrollments_hub_external_id_idx; Type: INDEX; Schema: enrollment; Owner: -
--

CREATE INDEX enrollments_hub_external_id_idx ON enrollment.enrollments USING btree (hub_external_id);


--
-- Name: enrollments_promoter_external_id_idx; Type: INDEX; Schema: enrollment; Owner: -
--

CREATE INDEX enrollments_promoter_external_id_idx ON enrollment.enrollments USING btree (promoter_external_id);


--
-- Name: enrollments_status_idx; Type: INDEX; Schema: enrollment; Owner: -
--

CREATE INDEX enrollments_status_idx ON enrollment.enrollments USING btree (status);


--
-- Name: fee_coordinator_external_id_idx; Type: INDEX; Schema: fees; Owner: -
--

CREATE INDEX fee_coordinator_external_id_idx ON fees.fee USING btree (coordinator_external_id);


--
-- Name: fee_payment_fee_id_idx; Type: INDEX; Schema: fees; Owner: -
--

CREATE INDEX fee_payment_fee_id_idx ON fees.fee_payment USING btree (fee_id);


--
-- Name: fee_payment_payment_id_idx; Type: INDEX; Schema: fees; Owner: -
--

CREATE UNIQUE INDEX fee_payment_payment_id_idx ON fees.fee_payment USING btree (payment_id);


--
-- Name: fee_payment_status_idx; Type: INDEX; Schema: fees; Owner: -
--

CREATE INDEX fee_payment_status_idx ON fees.fee_payment USING btree (status);


--
-- Name: fee_status_idx; Type: INDEX; Schema: fees; Owner: -
--

CREATE INDEX fee_status_idx ON fees.fee USING btree (status);


--
-- Name: fee_student_external_id_idx; Type: INDEX; Schema: fees; Owner: -
--

CREATE INDEX fee_student_external_id_idx ON fees.fee USING btree (student_external_id);


--
-- Name: hub_address_external_id_idx; Type: INDEX; Schema: hub; Owner: -
--

CREATE INDEX hub_address_external_id_idx ON hub.hub USING btree (address_external_id);


--
-- Name: hub_brand_idx; Type: INDEX; Schema: hub; Owner: -
--

CREATE INDEX hub_brand_idx ON hub.hub USING btree (brand);


--
-- Name: hub_coordinator_external_id_idx; Type: INDEX; Schema: hub; Owner: -
--

CREATE INDEX hub_coordinator_external_id_idx ON hub.hub USING btree (coordinator_external_id);


--
-- Name: ix_checkouts_external_id; Type: INDEX; Schema: infinitepay; Owner: -
--

CREATE INDEX ix_checkouts_external_id ON infinitepay.checkouts USING btree (external_id);


--
-- Name: ix_outbound_jobs_external_id; Type: INDEX; Schema: infinitepay; Owner: -
--

CREATE INDEX ix_outbound_jobs_external_id ON infinitepay.outbound_jobs USING btree (external_id);


--
-- Name: ix_outbound_jobs_next_attempt_at; Type: INDEX; Schema: infinitepay; Owner: -
--

CREATE INDEX ix_outbound_jobs_next_attempt_at ON infinitepay.outbound_jobs USING btree (next_attempt_at);


--
-- Name: ix_webhook_logs_external_id; Type: INDEX; Schema: infinitepay; Owner: -
--

CREATE INDEX ix_webhook_logs_external_id ON infinitepay.webhook_logs USING btree (external_id);


--
-- Name: checkouts_invoice_slug_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX checkouts_invoice_slug_idx ON lead.checkouts USING btree (invoice_slug);


--
-- Name: checkouts_is_paid_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX checkouts_is_paid_idx ON lead.checkouts USING btree (is_paid);


--
-- Name: checkouts_provider_payment_id_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX checkouts_provider_payment_id_idx ON lead.checkouts USING btree (provider_payment_id);


--
-- Name: checkouts_transaction_nsu_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX checkouts_transaction_nsu_idx ON lead.checkouts USING btree (transaction_nsu);


--
-- Name: leads_promoter_external_id_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX leads_promoter_external_id_idx ON lead.leads USING btree (promoter_external_id);


--
-- Name: leads_status_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX leads_status_idx ON lead.leads USING btree (status);


--
-- Name: messages_external_id_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX messages_external_id_idx ON lead.messages USING btree (external_id);


--
-- Name: messages_message_id_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX messages_message_id_idx ON lead.messages USING btree (message_id);


--
-- Name: messages_status_idx; Type: INDEX; Schema: lead; Owner: -
--

CREATE INDEX messages_status_idx ON lead.messages USING btree (status);


--
-- Name: contacts_email_idx; Type: INDEX; Schema: notify; Owner: -
--

CREATE INDEX contacts_email_idx ON notify.contacts USING btree (email);


--
-- Name: contacts_external_id_idx; Type: INDEX; Schema: notify; Owner: -
--

CREATE INDEX contacts_external_id_idx ON notify.contacts USING btree (external_id);


--
-- Name: contacts_phone_idx; Type: INDEX; Schema: notify; Owner: -
--

CREATE INDEX contacts_phone_idx ON notify.contacts USING btree (phone);


--
-- Name: logs_external_id_idx; Type: INDEX; Schema: notify; Owner: -
--

CREATE INDEX logs_external_id_idx ON notify.logs USING btree (external_id);


--
-- Name: logs_message_id_idx; Type: INDEX; Schema: notify; Owner: -
--

CREATE INDEX logs_message_id_idx ON notify.logs USING btree (message_id);


--
-- Name: messages_contact_id_idx; Type: INDEX; Schema: notify; Owner: -
--

CREATE INDEX messages_contact_id_idx ON notify.messages USING btree (contact_id);


--
-- Name: templates_slug_idx; Type: INDEX; Schema: notify; Owner: -
--

CREATE INDEX templates_slug_idx ON notify.templates USING btree (slug);


--
-- Name: otp_logs_external_id_idx; Type: INDEX; Schema: otp; Owner: -
--

CREATE INDEX otp_logs_external_id_idx ON otp.otp_logs USING btree (external_id);


--
-- Name: pending_notify_external_id_idx; Type: INDEX; Schema: otp; Owner: -
--

CREATE INDEX pending_notify_external_id_idx ON otp.pending_notify USING btree (external_id);


--
-- Name: pending_notify_otp_log_id_idx; Type: INDEX; Schema: otp; Owner: -
--

CREATE INDEX pending_notify_otp_log_id_idx ON otp.pending_notify USING btree (otp_log_id);


--
-- Name: profiles_created_at_idx; Type: INDEX; Schema: profiles; Owner: -
--

CREATE INDEX profiles_created_at_idx ON profiles.profiles USING btree (created_at);


--
-- Name: profiles_name_lower_idx; Type: INDEX; Schema: profiles; Owner: -
--

CREATE INDEX profiles_name_lower_idx ON profiles.profiles USING btree (lower((name)::text));


--
-- Name: promoters_external_id_idx; Type: INDEX; Schema: promoter; Owner: -
--

CREATE UNIQUE INDEX promoters_external_id_idx ON promoter.promoters USING btree (external_id);


--
-- Name: promoters_hub_external_id_idx; Type: INDEX; Schema: promoter; Owner: -
--

CREATE INDEX promoters_hub_external_id_idx ON promoter.promoters USING btree (hub_external_id);


--
-- Name: promoters_status_idx; Type: INDEX; Schema: promoter; Owner: -
--

CREATE INDEX promoters_status_idx ON promoter.promoters USING btree (status);


--
-- Name: user_roles_external_id_idx; Type: INDEX; Schema: roles; Owner: -
--

CREATE INDEX user_roles_external_id_idx ON roles.user_roles USING btree (external_id);


--
-- Name: student_diplomas_student_id_idx; Type: INDEX; Schema: student; Owner: -
--

CREATE INDEX student_diplomas_student_id_idx ON student.student_diplomas USING btree (student_id);


--
-- Name: student_documents_document_external_id_idx; Type: INDEX; Schema: student; Owner: -
--

CREATE INDEX student_documents_document_external_id_idx ON student.student_documents USING btree (document_external_id);


--
-- Name: student_documents_document_type_idx; Type: INDEX; Schema: student; Owner: -
--

CREATE INDEX student_documents_document_type_idx ON student.student_documents USING btree (document_type);


--
-- Name: student_documents_student_id_idx; Type: INDEX; Schema: student; Owner: -
--

CREATE INDEX student_documents_student_id_idx ON student.student_documents USING btree (student_id);


--
-- Name: student_exams_student_id_idx; Type: INDEX; Schema: student; Owner: -
--

CREATE INDEX student_exams_student_id_idx ON student.student_exams USING btree (student_id);


--
-- Name: students_external_id_idx; Type: INDEX; Schema: student; Owner: -
--

CREATE INDEX students_external_id_idx ON student.students USING btree (external_id);


--
-- Name: students_status_idx; Type: INDEX; Schema: student; Owner: -
--

CREATE INDEX students_status_idx ON student.students USING btree (status);


--
-- Name: external_id_idx; Type: INDEX; Schema: training; Owner: -
--

CREATE INDEX external_id_idx ON training.trainees USING btree (external_id);


--
-- Name: status_idx; Type: INDEX; Schema: training; Owner: -
--

CREATE INDEX status_idx ON training.trainees USING btree (status);


--
-- Name: submissions_external_id_idx; Type: INDEX; Schema: training; Owner: -
--

CREATE INDEX submissions_external_id_idx ON training.submissions USING btree (external_id);


--
-- Name: submissions_external_material_idx; Type: INDEX; Schema: training; Owner: -
--

CREATE INDEX submissions_external_material_idx ON training.submissions USING btree (external_id, material_id);


--
-- Name: submissions_material_id_idx; Type: INDEX; Schema: training; Owner: -
--

CREATE INDEX submissions_material_id_idx ON training.submissions USING btree (material_id);


--
-- Name: submissions_status_idx; Type: INDEX; Schema: training; Owner: -
--

CREATE INDEX submissions_status_idx ON training.submissions USING btree (status);


--
-- Name: profiles profiles_set_updated_at; Type: TRIGGER; Schema: profiles; Owner: -
--

CREATE TRIGGER profiles_set_updated_at BEFORE UPDATE ON profiles.profiles FOR EACH ROW EXECUTE FUNCTION profiles.set_updated_at();


--
-- Name: addresses addresses_external_id_fkey; Type: FK CONSTRAINT; Schema: addresses; Owner: -
--

ALTER TABLE ONLY addresses.addresses
    ADD CONSTRAINT addresses_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: entity_addresses entity_addresses_address_id_fkey; Type: FK CONSTRAINT; Schema: addresses; Owner: -
--

ALTER TABLE ONLY addresses.entity_addresses
    ADD CONSTRAINT entity_addresses_address_id_fkey FOREIGN KEY (address_id) REFERENCES addresses.entity_address_details(id) ON DELETE SET NULL;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(external_id) ON DELETE CASCADE;


--
-- Name: educational_data educational_data_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: enrollment; Owner: -
--

ALTER TABLE ONLY enrollment.educational_data
    ADD CONSTRAINT educational_data_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES enrollment.enrollments(id) ON DELETE CASCADE;


--
-- Name: checkouts checkouts_external_id_fkey; Type: FK CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.checkouts
    ADD CONSTRAINT checkouts_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: outbound_jobs outbound_jobs_external_id_fkey; Type: FK CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.outbound_jobs
    ADD CONSTRAINT outbound_jobs_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: webhook_logs webhook_logs_external_id_fkey; Type: FK CONSTRAINT; Schema: infinitepay; Owner: -
--

ALTER TABLE ONLY infinitepay.webhook_logs
    ADD CONSTRAINT webhook_logs_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: contacts contacts_external_id_fkey; Type: FK CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.contacts
    ADD CONSTRAINT contacts_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: logs logs_external_id_fkey; Type: FK CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.logs
    ADD CONSTRAINT logs_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: logs logs_message_id_fkey; Type: FK CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.logs
    ADD CONSTRAINT logs_message_id_fkey FOREIGN KEY (message_id) REFERENCES notify.messages(id) ON DELETE CASCADE;


--
-- Name: messages messages_contact_id_fkey; Type: FK CONSTRAINT; Schema: notify; Owner: -
--

ALTER TABLE ONLY notify.messages
    ADD CONSTRAINT messages_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES notify.contacts(id) ON DELETE CASCADE;


--
-- Name: otp_logs otp_logs_external_id_fkey; Type: FK CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.otp_logs
    ADD CONSTRAINT otp_logs_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_notify pending_notify_external_id_fkey; Type: FK CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.pending_notify
    ADD CONSTRAINT pending_notify_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: pending_notify pending_notify_otp_log_id_fkey; Type: FK CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.pending_notify
    ADD CONSTRAINT pending_notify_otp_log_id_fkey FOREIGN KEY (otp_log_id) REFERENCES otp.otp_logs(id) ON DELETE CASCADE;


--
-- Name: rate_limit rate_limit_external_id_fkey; Type: FK CONSTRAINT; Schema: otp; Owner: -
--

ALTER TABLE ONLY otp.rate_limit
    ADD CONSTRAINT rate_limit_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: birth_info birth_info_profile_id_fkey; Type: FK CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.birth_info
    ADD CONSTRAINT birth_info_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;


--
-- Name: educational educational_profile_id_fkey; Type: FK CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.educational
    ADD CONSTRAINT educational_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES profiles.profiles(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_external_id_fkey; Type: FK CONSTRAINT; Schema: profiles; Owner: -
--

ALTER TABLE ONLY profiles.profiles
    ADD CONSTRAINT profiles_external_id_fkey FOREIGN KEY (external_id) REFERENCES auth.users(external_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: student_diplomas student_diplomas_student_id_fkey; Type: FK CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_diplomas
    ADD CONSTRAINT student_diplomas_student_id_fkey FOREIGN KEY (student_id) REFERENCES student.students(id) ON DELETE CASCADE;


--
-- Name: student_documents student_documents_student_id_fkey; Type: FK CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_documents
    ADD CONSTRAINT student_documents_student_id_fkey FOREIGN KEY (student_id) REFERENCES student.students(id) ON DELETE CASCADE;


--
-- Name: student_exams student_exams_student_id_fkey; Type: FK CONSTRAINT; Schema: student; Owner: -
--

ALTER TABLE ONLY student.student_exams
    ADD CONSTRAINT student_exams_student_id_fkey FOREIGN KEY (student_id) REFERENCES student.students(id) ON DELETE CASCADE;


--
-- Name: submissions submissions_material_id_fkey; Type: FK CONSTRAINT; Schema: training; Owner: -
--

ALTER TABLE ONLY training.submissions
    ADD CONSTRAINT submissions_material_id_fkey FOREIGN KEY (material_id) REFERENCES training.materials(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict RYf2HbdMRU1iXX4CpdQ6B9G6TuocZR6yS5yf6gtudpq2SjI43yFMtgmxsKj8hwF

